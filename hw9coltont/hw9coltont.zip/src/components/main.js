function MyMain() {
    return (

        <main>
            <p>Welcome to my webpage!</p>
        </main>
    )
}

export default MyMain