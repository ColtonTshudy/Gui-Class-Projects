/*
 * author: Colton Tshudy
 * version: 4/29/2023
 */

function MyFooter() {
    return (
        <footer>
            <p>Footer of the webpage :D</p>
        </footer>
    )
}

export default MyFooter